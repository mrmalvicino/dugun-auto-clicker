﻿Class form1

    'VERSION REFERENCE
    '+ (0.0.0.1): Small code modifications
    '+ (0.0.1.0): Big code modifications
    '+ (0.1.0.0): Design modifications
    '+ (1.0.0.0): Program remake

    Dim Loader As IO.StreamReader
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Short

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        'HOTKEYS
        If (GetAsyncKeyState(17)) Then
            If (GetAsyncKeyState(81)) Then 'Q: STOP ALL
                Form2.Autoclicker1a.Stop()
                Form2.Autoclicker1b.Stop()
                Form2.Autoclicker2.Stop()
                Form2.Autoclicker3.Stop()
                Form2.Recorder.Stop()
                Form3.Autotyper.Stop()
            ElseIf (GetAsyncKeyState(87)) Then 'W: START AUTOCLICKER
                If Form2.ComboBox1.SelectedItem = "Mode 1: Stage position" Then
                    Form2.Autoclicker2.Stop()
                    Form2.Autoclicker3.Stop()
                    Form2.Recorder.Stop()
                    Form3.Autotyper.Stop()
                    Form2.NumericUpDown1.Value = 1
                    If Form2.TextBox1.Text = 0 Then
                        Form2.Autoclicker1b.Start()
                    Else
                        Form2.Autoclicker1a.Interval = Form2.TextBox1.Text * 1000
                        Form2.Autoclicker1a.Start()
                    End If
                End If
                If Form2.ComboBox1.SelectedItem = "Mode 2: Single position" Then
                    Form2.Autoclicker1a.Stop()
                    Form2.Autoclicker1b.Stop()
                    Form2.Autoclicker3.Stop()
                    Form2.Recorder.Stop()
                    Form3.Autotyper.Stop()
                    If Not Form2.TextBox1.Text = 0 Then
                        Form2.Autoclicker2.Interval = Form2.TextBox1.Text * 1000
                    End If
                    Form2.Autoclicker2.Start()
                End If
                If Form2.ComboBox1.SelectedItem = "Mode 3: Current position" Then
                    Form2.Autoclicker1a.Stop()
                    Form2.Autoclicker1b.Stop()
                    Form2.Autoclicker2.Stop()
                    Form2.Recorder.Stop()
                    Form3.Autotyper.Stop()
                    If Not Form2.TextBox1.Text = 0 Then
                        Form2.Autoclicker3.Interval = Form2.TextBox1.Text * 1000
                    End If
                    Form2.Autoclicker3.Start()
                End If
            End If
            If (GetAsyncKeyState(69)) Then 'E: NOTE DOWN POSITION
                Form2.TextBox2.Text = Label6.Text
                Form2.TextBox3.Text = Label8.Text
            End If

            If (GetAsyncKeyState(82)) Then 'R: RECORD POSITION
                Form2.Autoclicker1a.Stop()
                Form2.Autoclicker1b.Stop()
                Form2.Autoclicker2.Stop()
                Form2.Autoclicker3.Stop()
                Form3.Autotyper.Stop()
                Form2.ListBox1.Items.Clear() 'SHARED
                Form2.ListBox2.Items.Clear() 'SHARED
                Form2.ListBox3.Items.Clear() 'SHARED
                Form2.Recorder.Start()
                Form2.TextBox1.Text = "0"
            End If

            If (GetAsyncKeyState(84)) Then 'T: START AUTOTYPER
                Form2.Autoclicker1a.Stop()
                Form2.Autoclicker1b.Stop()
                Form2.Autoclicker2.Stop()
                Form2.Autoclicker3.Stop()
                Form2.Recorder.Stop()
                Form3.Autotyper.Interval = Form3.TextBox2.Text * 1000
                Form3.Autotyper.Start()
            End If
        End If

        If (GetAsyncKeyState(112)) Then 'HELP
            Form4.Show()
        End If

        'CURRENT STATUS
        If Form2.Autoclicker1a.Enabled = True Then
            Label2.ForeColor = Color.Green
            Label2.Text = "Mode 1 on"
        ElseIf Form2.Autoclicker1b.Enabled = True Then
            Label2.ForeColor = Color.Green
            Label2.Text = "Mode 1 on"
        ElseIf Form2.Autoclicker2.Enabled = True Then
            Label2.ForeColor = Color.Green
            Label2.Text = "Mode 2 on"
        ElseIf Form2.Autoclicker3.Enabled = True Then
            Label2.ForeColor = Color.Green
            Label2.Text = "Mode 3 on"
        ElseIf Form2.Recorder.Enabled = True Then
            Label2.ForeColor = Color.Yellow
            Label2.Text = "Recording"
        Else
            Label2.ForeColor = Color.Red
            Label2.Text = "Inactive"
        End If

        If Form3.Autotyper.Enabled = True Then
            Label4.ForeColor = Color.Green
            Label4.Text = "Typing"
        Else
            Label4.ForeColor = Color.Red
            Label4.Text = "Inactive"
        End If

        'MOUSE POSITION STATUS
        Dim x_mouse_coordinate As Integer = form1.MousePosition.X
        Dim y_mouse_coordinate As Integer = form1.MousePosition.Y
        Label6.Text = x_mouse_coordinate
        Label8.Text = y_mouse_coordinate

        'CLICK EVENT STATUS
        If GetAsyncKeyState(Keys.LButton) Then
            Label10.Text = "Left click"
        ElseIf GetAsyncKeyState(Keys.RButton) Then
            Label10.Text = "Right click"
        ElseIf GetAsyncKeyState(Keys.RButton) Then
            Label10.Text = "Right click"
        ElseIf GetAsyncKeyState(Keys.MButton) Then
            Label10.Text = "Middle click"
        Else
            Label10.Text = "None"
        End If

    End Sub

    Private Sub LoadAutoclickerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoadAutoclickerToolStripMenuItem.Click
        Try
            Form2.Timer1.Stop()

            Loader = IO.File.OpenText("C:\Dugun\Click events.txt")
            Dim loaded_click_events() As String = Loader.ReadToEnd.Split(vbNewLine)
            Form2.ListBox1.Items.AddRange(loaded_click_events)

            Loader = IO.File.OpenText("C:\Dugun\X coordinates.txt")
            Dim loaded_X_coordinates() As String = Loader.ReadToEnd.Split(vbNewLine)
            Form2.ListBox2.Items.AddRange(loaded_X_coordinates)

            Loader = IO.File.OpenText("C:\Dugun\Y coordinates.txt")
            Dim loaded_Y_coordinates() As String = Loader.ReadToEnd.Split(vbNewLine)
            Form2.ListBox3.Items.AddRange(loaded_Y_coordinates)

            Form2.ListBox1.SelectedIndex = 1
            Form2.ListBox2.SelectedIndex = 1
            Form2.ListBox3.SelectedIndex = 1

            Form2.Timer1.Start()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub SaveAutoclickerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAutoclickerToolStripMenuItem.Click
        Try
            FileOpen(1, "C:\Dugun\Click events.txt", OpenMode.Output)
            For i = 0 To Form2.ListBox1.Items.Count - 1
                PrintLine(1, Form2.ListBox1.Items(i))
            Next

            FileOpen(2, "C:\Dugun\X coordinates.txt", OpenMode.Output)
            For i = 0 To Form2.ListBox2.Items.Count - 1
                PrintLine(2, Form2.ListBox2.Items(i))
            Next

            FileOpen(3, "C:\Dugun\Y coordinates.txt", OpenMode.Output)
            For i = 0 To Form2.ListBox3.Items.Count - 1
                PrintLine(3, Form2.ListBox3.Items(i))
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub HideToolsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HideToolsToolStripMenuItem.Click
        Form2.Hide()
        Form3.Hide()
    End Sub

    Private Sub AutoclickerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AutoclickerToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub AutotyperToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AutotyperToolStripMenuItem.Click
        Form3.Show()
    End Sub

    Private Sub ViewHelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewHelpToolStripMenuItem.Click
        Form4.Show()
    End Sub

    Private Sub AboutDugunToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutDugunToolStripMenuItem.Click
        Form5.Show()
    End Sub

End Class
