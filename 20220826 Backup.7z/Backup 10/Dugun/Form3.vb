﻿Public Class Form3

    Private Sub Autotyper_Tick(sender As Object, e As EventArgs) Handles Autotyper.Tick
        SendKeys.Send(TextBox1.Text & "{ENTER}")

        'RANDOM
        If CheckBox1.Checked = True Then
            Dim Random_new As Random
            Random_new = New Random
            Dim Random_value As Integer = Random_new.Next(0, 250)
            Autotyper.Interval = TextBox1.Text * 1000 + Random_value
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Text = ComboBox1.SelectedItem & TextBox1.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ComboBox2.SelectedItem & TextBox1.Text
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Text = ComboBox3.SelectedItem & TextBox1.Text
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") _
          AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub
End Class