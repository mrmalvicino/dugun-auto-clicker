﻿Public Class Form2

    Public Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Integer, ByVal dx As Integer, ByVal dy As Integer, ByVal cButtons As Integer, ByVal dwExtraInfo As Integer)
    Public Const MOUSEEVENTF_LEFTDOWN = &H2 ' left button down
    Public Const MOUSEEVENTF_LEFTUP = &H4 ' left button up
    Public Const MOUSEEVENTF_MIDDLEDOWN = &H20 ' middle button down
    Public Const MOUSEEVENTF_MIDDLEUP = &H40 ' middle button up
    Public Const MOUSEEVENTF_RIGHTDOWN = &H8 ' right button down
    Public Const MOUSEEVENTF_RIGHTUP = &H10 ' right button up

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        'COMBOBOXES TEXT
        If ComboBox1.SelectedItem = "" Then
            ComboBox1.Text = "Mode 1: Stage position"
        Else
            ComboBox1.Text = ComboBox1.SelectedItem
        End If

        If ComboBox2.SelectedItem = "" Then
            ComboBox2.Text = "Left click"
        Else
            ComboBox2.Text = ComboBox2.SelectedItem
        End If

        'CURRENT STAGE LINK WITH ROW INDEX
        If NumericUpDown1.Value > 0 And NumericUpDown1.Value < ListBox1.Items.Count Or NumericUpDown1.Value = ListBox1.Items.Count Then
            ListBox1.SelectedIndex = NumericUpDown1.Value - 1
            ListBox2.SelectedIndex = NumericUpDown1.Value - 1
            ListBox3.SelectedIndex = NumericUpDown1.Value - 1
        End If

        'CURRENT STAGE MIN & MAX
        If Not ListBox1.Items.Count = 0 Then
            NumericUpDown1.Minimum = 1
            NumericUpDown1.Maximum = ListBox1.Items.Count
        Else
            NumericUpDown1.Minimum = 1
            NumericUpDown1.Maximum = 1000000000000
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") _
          AndAlso e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> "," Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") _
          AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") _
          AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If Not (ComboBox2.SelectedItem = "" Or TextBox2.Text = "" Or TextBox3.Text = "") Then
            ListBox1.Items.Add(ComboBox2.SelectedItem)
            ListBox2.Items.Add(TextBox2.Text)
            ListBox3.Items.Add(TextBox3.Text)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Not (ListBox1.Items.Count = 0 Or ComboBox2.SelectedItem = "" Or TextBox2.Text = "" Or TextBox3.Text = "") Then
            ListBox1.Items.Insert(ListBox1.SelectedIndex, ComboBox2.SelectedItem)
            ListBox2.Items.Insert(ListBox2.SelectedIndex, TextBox2.Text)
            ListBox3.Items.Insert(ListBox3.SelectedIndex, TextBox3.Text)
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Not (ListBox1.Items.Count = 0 Or ComboBox2.SelectedItem = "" Or TextBox2.Text = "" Or TextBox3.Text = "") Then
            Dim listbox1_current_index As Integer
            Dim listbox2_current_index As Integer
            Dim listbox3_current_index As Integer

            listbox1_current_index = ListBox1.SelectedIndex
            listbox2_current_index = ListBox2.SelectedIndex
            listbox3_current_index = ListBox3.SelectedIndex

            ListBox1.Items.Remove(ListBox1.SelectedItem)
            ListBox2.Items.Remove(ListBox2.SelectedItem)
            ListBox3.Items.Remove(ListBox3.SelectedItem)

            ListBox1.Items.Insert(listbox1_current_index, ComboBox2.SelectedItem)
            ListBox2.Items.Insert(listbox2_current_index, TextBox2.Text)
            ListBox3.Items.Insert(listbox3_current_index, TextBox3.Text)
        End If
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        ListBox1.Items.Remove(ListBox1.SelectedItem)
        ListBox2.Items.Remove(ListBox2.SelectedItem)
        ListBox3.Items.Remove(ListBox3.SelectedItem)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ListBox1.Items.Clear() 'SHARED
        ListBox2.Items.Clear() 'SHARED
        ListBox3.Items.Clear() 'SHARED
    End Sub

    Private Sub Autoclicker1a_Tick(sender As Object, e As EventArgs) Handles Autoclicker1a.Tick
        'GO TO POSITION
        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(ListBox2.SelectedItem, ListBox3.SelectedItem)

        'CLICK
        If ListBox1.SelectedItem = "Left click" Then
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        ElseIf ListBox1.SelectedItem = "Middle click" Then
            mouse_event(MOUSEEVENTF_MIDDLEDOWN, 0, 0, 0, 0)
            mouse_event(MOUSEEVENTF_MIDDLEUP, 0, 0, 0, 0)
        ElseIf ListBox1.SelectedItem = "Right click" Then
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
        End If

        'NEXT STAGE
        If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 Then
            NumericUpDown1.Value = 1
        Else
            NumericUpDown1.Value = NumericUpDown1.Value + 1
        End If

        'RANDOM
        If CheckBox1.Checked = True Then
            Dim Random_new As Random
            Random_new = New Random
            Dim Random_value As Integer = Random_new.Next(0, 250)
            Autoclicker1a.Interval = TextBox1.Text * 1000 + Random_value
        End If
    End Sub

    Private Sub Autoclicker1b_Tick(sender As Object, e As EventArgs) Handles Autoclicker1b.Tick
        'GO TO POSITION
        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(ListBox2.SelectedItem, ListBox3.SelectedItem)

        'CLICK
        If ListBox1.SelectedItem = "Left click" Then
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        ElseIf ListBox1.SelectedItem = "Middle click" Then
            mouse_event(MOUSEEVENTF_MIDDLEDOWN, 0, 0, 0, 0)
            mouse_event(MOUSEEVENTF_MIDDLEUP, 0, 0, 0, 0)
        ElseIf ListBox1.SelectedItem = "Right click" Then
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
        End If

        'NEXT STAGE
        If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 Then
            NumericUpDown1.Value = 1
        Else
            NumericUpDown1.Value = NumericUpDown1.Value + 1
        End If

        'RANDOM
        If CheckBox1.Checked = True Then
            Dim Random_new As Random
            Random_new = New Random
            Dim Random_value As Integer = Random_new.Next(10, 30)
            Autoclicker1b.Interval = Random_value
        End If
    End Sub

    Private Sub Autoclicker2_Tick(sender As Object, e As EventArgs) Handles Autoclicker2.Tick
        Me.Cursor = New Cursor(Cursor.Current.Handle)
        Cursor.Position = New Point(TextBox2.Text, TextBox3.Text)
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)

        'RANDOM
        If CheckBox1.Checked = True Then
            Dim Random_new As Random
            Random_new = New Random
            Dim Random_value As Integer = Random_new.Next(0, 250)
            Autoclicker2.Interval = TextBox1.Text * 1000 + Random_value
        End If
    End Sub

    Private Sub Autoclicker3_Tick(sender As Object, e As EventArgs) Handles Autoclicker3.Tick
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)

        'RANDOM
        If CheckBox1.Checked = True Then
            Dim Random_new As Random
            Random_new = New Random
            Dim Random_value As Integer = Random_new.Next(0, 250)
            Autoclicker3.Interval = TextBox1.Text * 1000 + Random_value
        End If
    End Sub

    Private Sub Recorder_Tick(sender As Object, e As EventArgs) Handles Recorder.Tick
        ListBox1.Items.Add(form1.Label10.Text)
        ListBox2.Items.Add(form1.Label6.Text)
        ListBox3.Items.Add(form1.Label8.Text)
    End Sub
End Class