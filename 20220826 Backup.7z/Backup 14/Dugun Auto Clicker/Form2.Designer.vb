﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(12, 12)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {999999, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {999999, 0, 0, -2147483648})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(100, 22)
        Me.NumericUpDown1.TabIndex = 0
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 40)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 22)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "Status"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(118, 40)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 22)
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.Text = "Estado"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(12, 68)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 22)
        Me.TextBox3.TabIndex = 3
        Me.TextBox3.Text = "Help"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(118, 68)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 22)
        Me.TextBox4.TabIndex = 4
        Me.TextBox4.Text = "Ayuda"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(12, 96)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 22)
        Me.TextBox5.TabIndex = 5
        Me.TextBox5.Text = "Stages"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(118, 96)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 22)
        Me.TextBox6.TabIndex = 6
        Me.TextBox6.Text = "Etapas"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(12, 124)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 22)
        Me.TextBox7.TabIndex = 7
        Me.TextBox7.Text = "Options"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(118, 124)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 22)
        Me.TextBox8.TabIndex = 8
        Me.TextBox8.Text = "Opciones"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(12, 152)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 22)
        Me.TextBox9.TabIndex = 9
        Me.TextBox9.Text = "Mouse Pattern"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(118, 152)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 22)
        Me.TextBox10.TabIndex = 10
        Me.TextBox10.Text = "Patrón Del Mouse"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(12, 180)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 22)
        Me.TextBox11.TabIndex = 11
        Me.TextBox11.Text = "Effects"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(118, 180)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(100, 22)
        Me.TextBox12.TabIndex = 12
        Me.TextBox12.Text = "Efectos"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(12, 208)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(100, 22)
        Me.TextBox13.TabIndex = 13
        Me.TextBox13.Text = "Text"
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(118, 208)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(100, 22)
        Me.TextBox14.TabIndex = 14
        Me.TextBox14.Text = "Texto"
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(12, 236)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(100, 22)
        Me.TextBox15.TabIndex = 28
        Me.TextBox15.Text = "Stop (s):"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(118, 236)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(100, 22)
        Me.TextBox16.TabIndex = 27
        Me.TextBox16.Text = "Parar (s):"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(12, 264)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(100, 22)
        Me.TextBox17.TabIndex = 26
        Me.TextBox17.Text = "Row:"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(118, 264)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(100, 22)
        Me.TextBox18.TabIndex = 25
        Me.TextBox18.Text = "Fila:"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(12, 292)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(100, 22)
        Me.TextBox19.TabIndex = 24
        Me.TextBox19.Text = "Coordinates (x;y):"
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(118, 292)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(100, 22)
        Me.TextBox20.TabIndex = 23
        Me.TextBox20.Text = "Coordenadas (x;y):"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(12, 320)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(100, 22)
        Me.TextBox21.TabIndex = 22
        Me.TextBox21.Text = "Recorder interval (ms):"
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(118, 320)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(100, 22)
        Me.TextBox22.TabIndex = 21
        Me.TextBox22.Text = "Intervalo de grabadora (ms):"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(12, 348)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(100, 22)
        Me.TextBox23.TabIndex = 20
        Me.TextBox23.Text = "Random (px):"
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(118, 348)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(100, 22)
        Me.TextBox24.TabIndex = 19
        Me.TextBox24.Text = "Aleatorio (px):"
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(12, 376)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(100, 22)
        Me.TextBox25.TabIndex = 18
        Me.TextBox25.Text = "Stages interval (ms):"
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(118, 376)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(100, 22)
        Me.TextBox26.TabIndex = 17
        Me.TextBox26.Text = "Intervalo de etapas (ms):"
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(12, 404)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(100, 22)
        Me.TextBox27.TabIndex = 16
        Me.TextBox27.Text = "Random (ms):"
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(118, 404)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(100, 22)
        Me.TextBox28.TabIndex = 15
        Me.TextBox28.Text = "Aleatorio (ms):"
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(12, 432)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(100, 22)
        Me.TextBox29.TabIndex = 56
        Me.TextBox29.Text = "Reloop deelay (ms):"
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(118, 432)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(100, 22)
        Me.TextBox30.TabIndex = 55
        Me.TextBox30.Text = "Retraso de repetición"
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(224, 40)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(100, 22)
        Me.TextBox31.TabIndex = 54
        Me.TextBox31.Text = "Typing interval (ms):"
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(330, 40)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(100, 22)
        Me.TextBox32.TabIndex = 53
        Me.TextBox32.Text = "Intervalo de tipeo (ms):"
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(224, 68)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(100, 22)
        Me.TextBox33.TabIndex = 52
        Me.TextBox33.Text = "Español"
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(330, 68)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(100, 22)
        Me.TextBox34.TabIndex = 51
        Me.TextBox34.Text = "English"
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(224, 96)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(100, 22)
        Me.TextBox35.TabIndex = 50
        Me.TextBox35.Text = "Hotkeys"
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(330, 96)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(100, 22)
        Me.TextBox36.TabIndex = 49
        Me.TextBox36.Text = "Teclas"
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(224, 124)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(100, 22)
        Me.TextBox37.TabIndex = 48
        Me.TextBox37.Text = "Website"
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(330, 124)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(100, 22)
        Me.TextBox38.TabIndex = 47
        Me.TextBox38.Text = "Sitio Web"
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(224, 152)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(100, 22)
        Me.TextBox39.TabIndex = 46
        Me.TextBox39.Text = "Add"
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(330, 152)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(100, 22)
        Me.TextBox40.TabIndex = 45
        Me.TextBox40.Text = "Agregar"
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(224, 180)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(100, 22)
        Me.TextBox41.TabIndex = 44
        Me.TextBox41.Text = "Insert"
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(330, 180)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(100, 22)
        Me.TextBox42.TabIndex = 43
        Me.TextBox42.Text = "Insertar"
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(224, 208)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(100, 22)
        Me.TextBox43.TabIndex = 42
        Me.TextBox43.Text = "Delete"
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(330, 208)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(100, 22)
        Me.TextBox44.TabIndex = 41
        Me.TextBox44.Text = "Eliminar"
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(224, 236)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(100, 22)
        Me.TextBox45.TabIndex = 40
        Me.TextBox45.Text = "Clear"
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(330, 236)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(100, 22)
        Me.TextBox46.TabIndex = 39
        Me.TextBox46.Text = "Limpiar"
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(224, 264)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(100, 22)
        Me.TextBox47.TabIndex = 38
        Me.TextBox47.Text = "Save"
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(330, 264)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(100, 22)
        Me.TextBox48.TabIndex = 37
        Me.TextBox48.Text = "Guardar"
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(224, 292)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(100, 22)
        Me.TextBox49.TabIndex = 36
        Me.TextBox49.Text = "Load"
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(330, 292)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(100, 22)
        Me.TextBox50.TabIndex = 35
        Me.TextBox50.Text = "Cargar"
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(224, 320)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(100, 22)
        Me.TextBox51.TabIndex = 34
        Me.TextBox51.Text = "Stop (min):"
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(330, 320)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(100, 22)
        Me.TextBox52.TabIndex = 33
        Me.TextBox52.Text = "Parar (min):"
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(224, 348)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(100, 22)
        Me.TextBox53.TabIndex = 32
        Me.TextBox53.Text = "Reloop"
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(330, 348)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(100, 22)
        Me.TextBox54.TabIndex = 31
        Me.TextBox54.Text = "Repetir"
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(224, 376)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(100, 22)
        Me.TextBox55.TabIndex = 30
        Me.TextBox55.Text = "Activate"
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(330, 376)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(100, 22)
        Me.TextBox56.TabIndex = 29
        Me.TextBox56.Text = "Activar"
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(224, 404)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(100, 22)
        Me.TextBox57.TabIndex = 57
        Me.TextBox57.Text = "Random"
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(330, 404)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(100, 22)
        Me.TextBox58.TabIndex = 58
        Me.TextBox58.Text = "Aleatorio"
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(224, 432)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(100, 22)
        Me.TextBox59.TabIndex = 59
        Me.TextBox59.Text = "Insert text here"
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(330, 432)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(100, 22)
        Me.TextBox60.TabIndex = 60
        Me.TextBox60.Text = "Insertar texto aquí"
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(436, 40)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(100, 22)
        Me.TextBox61.TabIndex = 61
        Me.TextBox61.Text = "Color and movement effects"
        '
        'TextBox62
        '
        Me.TextBox62.Location = New System.Drawing.Point(542, 40)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(100, 22)
        Me.TextBox62.TabIndex = 62
        Me.TextBox62.Text = "Efectos de color y movimiento"
        '
        'TextBox63
        '
        Me.TextBox63.Location = New System.Drawing.Point(436, 68)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(100, 22)
        Me.TextBox63.TabIndex = 63
        Me.TextBox63.Text = "Special effects"
        '
        'TextBox64
        '
        Me.TextBox64.Location = New System.Drawing.Point(542, 68)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(100, 22)
        Me.TextBox64.TabIndex = 64
        Me.TextBox64.Text = "Efectos especiales"
        '
        'TextBox65
        '
        Me.TextBox65.Location = New System.Drawing.Point(436, 96)
        Me.TextBox65.Multiline = True
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(100, 22)
        Me.TextBox65.TabIndex = 65
        Me.TextBox65.Text = resources.GetString("TextBox65.Text")
        '
        'TextBox66
        '
        Me.TextBox66.Location = New System.Drawing.Point(542, 96)
        Me.TextBox66.Multiline = True
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(100, 22)
        Me.TextBox66.TabIndex = 66
        Me.TextBox66.Text = resources.GetString("TextBox66.Text")
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(694, 474)
        Me.Controls.Add(Me.TextBox66)
        Me.Controls.Add(Me.TextBox65)
        Me.Controls.Add(Me.TextBox64)
        Me.Controls.Add(Me.TextBox63)
        Me.Controls.Add(Me.TextBox62)
        Me.Controls.Add(Me.TextBox61)
        Me.Controls.Add(Me.TextBox60)
        Me.Controls.Add(Me.TextBox59)
        Me.Controls.Add(Me.TextBox58)
        Me.Controls.Add(Me.TextBox57)
        Me.Controls.Add(Me.TextBox29)
        Me.Controls.Add(Me.TextBox30)
        Me.Controls.Add(Me.TextBox31)
        Me.Controls.Add(Me.TextBox32)
        Me.Controls.Add(Me.TextBox33)
        Me.Controls.Add(Me.TextBox34)
        Me.Controls.Add(Me.TextBox35)
        Me.Controls.Add(Me.TextBox36)
        Me.Controls.Add(Me.TextBox37)
        Me.Controls.Add(Me.TextBox38)
        Me.Controls.Add(Me.TextBox39)
        Me.Controls.Add(Me.TextBox40)
        Me.Controls.Add(Me.TextBox41)
        Me.Controls.Add(Me.TextBox42)
        Me.Controls.Add(Me.TextBox43)
        Me.Controls.Add(Me.TextBox44)
        Me.Controls.Add(Me.TextBox45)
        Me.Controls.Add(Me.TextBox46)
        Me.Controls.Add(Me.TextBox47)
        Me.Controls.Add(Me.TextBox48)
        Me.Controls.Add(Me.TextBox49)
        Me.Controls.Add(Me.TextBox50)
        Me.Controls.Add(Me.TextBox51)
        Me.Controls.Add(Me.TextBox52)
        Me.Controls.Add(Me.TextBox53)
        Me.Controls.Add(Me.TextBox54)
        Me.Controls.Add(Me.TextBox55)
        Me.Controls.Add(Me.TextBox56)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.TextBox23)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.TextBox27)
        Me.Controls.Add(Me.TextBox28)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form2"
        Me.Text = "Dugun"
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
End Class
