﻿Public Class Form1
    Private Declare Sub mouse_event Lib "user32" _
   (ByVal dwFlags As Integer, ByVal dx As Integer _
   , ByVal dy As Integer, ByVal cButtons As Integer _
   , ByVal dwExtraInfo As Integer)

    Private Const MOUSEEVENTF_LEFTDOWN = &H2
    Private Const MOUSEEVENTF_LEFTUP = &H4
    Private Const MOUSEEVENTF_RIGHTDOWN = &H8
    Private Const MOUSEEVENTF_RIGHTUP = &H10

    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ListBox2.Items.Add("")
        ListBox3.Items.Add("")
        ListBox4.Items.Add("")

        ListBox2.SelectedIndex = 1
        ListBox3.SelectedIndex = 1
        ListBox4.SelectedIndex = 1

        Timer1.Interval = TextBox1.Text * 1000

        Timer1.Start()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Stop()
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        TextBox2.Text = ""
        TextBox3.Text = ""
        ComboBox3.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox2.Text = "" Then
            If RadioButton5.Checked = True Then
                MsgBox(tre.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
            Else
                MsgBox(tre.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
            End If
        Else
            If TextBox3.Text = "" Then
                If RadioButton5.Checked = True Then
                    MsgBox(tre.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
                Else
                    MsgBox(tre.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
                End If
            Else
                If ComboBox3.Text = "" Then
                    If RadioButton5.Checked = True Then
                        MsgBox(tre.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
                    Else
                        MsgBox(tre.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
                    End If
                Else
                    ListBox2.Items.Add(TextBox2.Text)
                    ListBox3.Items.Add(TextBox3.Text)
                    ListBox4.Items.Add(ComboBox3.Text)
                End If
            End If
        End If

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        If ListBox2.SelectedIndex = -1 Then
        Else
            ListBox2.Items.RemoveAt(ListBox2.SelectedIndex)
            ListBox3.Items.RemoveAt(ListBox3.SelectedIndex)
            ListBox4.Items.RemoveAt(ListBox4.SelectedIndex)
        End If
    End Sub

    Private Sub hot_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles hot.Tick
        Dim ctrl As Boolean
        Dim x As Boolean
        Dim q As Boolean
        Dim w As Boolean

        ctrl = GetAsyncKeyState(Keys.ControlKey)
        x = GetAsyncKeyState(Keys.X)
        q = GetAsyncKeyState(Keys.Q)
        w = GetAsyncKeyState(Keys.W)

        If ctrl And x = True Then
            TextBox2.Text = Cursor.Position.X
            TextBox3.Text = Cursor.Position.Y
        End If

        If ctrl And q = True Then
            ListBox2.SelectedIndex = 1
            ListBox3.SelectedIndex = 1
            ListBox4.SelectedIndex = 1

            Timer1.Interval = TextBox1.Text * 1000

            Timer1.Start()
        End If

        If ctrl And w = True Then
            Timer1.Stop()
        End If


        If ListBox2.SelectedIndex = -1 Then
        Else
            ListBox3.SelectedIndex = ListBox2.SelectedIndex
            ListBox4.SelectedIndex = ListBox2.SelectedIndex
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If ListBox2.SelectedIndex = ListBox2.Items.Count - 1 = True Then
            If CheckBox1.Checked = True Then
                Timer1.Stop()
            Else
                ListBox2.SelectedIndex = 1
                ListBox3.SelectedIndex = 1
                ListBox4.SelectedIndex = 1
            End If
        Else
            ListBox4.SelectedIndex = ListBox4.SelectedIndex + 1
            ListBox3.SelectedIndex = ListBox3.SelectedIndex + 1
            ListBox2.SelectedIndex = ListBox2.SelectedIndex + 1

            Cursor.Position = New Point(ListBox2.SelectedItem, ListBox3.SelectedItem)

            If ListBox4.SelectedItem = "Left Click" Then
                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
            End If

            If ListBox4.SelectedItem = "Click Izquierdo" Then
                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
            End If

            If ListBox4.SelectedItem = "Right Click" Then
                mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
                mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
            End If

            If ListBox4.SelectedItem = "Click Derecho" Then
                mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
                mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
            End If

        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ListBox2.Items.Clear()
        ListBox2.Items.Add("")
        ListBox3.Items.Add("")
        ListBox4.Items.Add("")

        Dim Name As String
        OpenFileDialog1.Filter = ""
        OpenFileDialog1.FilterIndex = 2
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.FileName = OpenFileDialog1.FileName
        FileOpen(3, OpenFileDialog1.FileName, OpenMode.Input)
        Do While Not EOF(3)
            Name = LineInput(3)
            If Len(Trim(Name)) > 0 Then
                ListBox2.Items.Add(Trim(Name))
            End If
        Loop
        FileClose(3)
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        ListBox3.Items.Clear()
        ListBox2.Items.Add("")
        ListBox3.Items.Add("")
        ListBox4.Items.Add("")

        Dim Name As String
        OpenFileDialog1.Filter = ""
        OpenFileDialog1.FilterIndex = 2
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.FileName = OpenFileDialog1.FileName
        FileOpen(3, OpenFileDialog1.FileName, OpenMode.Input)
        Do While Not EOF(3)
            Name = LineInput(3)
            If Len(Trim(Name)) > 0 Then
                ListBox3.Items.Add(Trim(Name))
            End If
        Loop
        FileClose(3)
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        ListBox4.Items.Clear()
        ListBox2.Items.Add("")
        ListBox3.Items.Add("")
        ListBox4.Items.Add("")

        Dim Name As String
        OpenFileDialog1.Filter = ""
        OpenFileDialog1.FilterIndex = 2
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.FileName = OpenFileDialog1.FileName
        FileOpen(3, OpenFileDialog1.FileName, OpenMode.Input)
        Do While Not EOF(3)
            Name = LineInput(3)
            If Len(Trim(Name)) > 0 Then
                ListBox4.Items.Add(Trim(Name))
            End If
        Loop
        FileClose(3)
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox4.Items.Count - 1
                            StreamW.WriteLine(ListBox4.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox4.Items.Count - 1
                        StreamW.WriteLine(ListBox4.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox4.Items.Count - 1
                            StreamW.WriteLine(ListBox4.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox4.Items.Count - 1
                        StreamW.WriteLine(ListBox4.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox4.Items.Count - 1
                            StreamW.WriteLine(ListBox4.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox4.Items.Count - 1
                        StreamW.WriteLine(ListBox4.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(tre.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox4.Items.Count - 1
                            StreamW.WriteLine(ListBox4.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox4.Items.Count - 1
                        StreamW.WriteLine(ListBox4.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        tre.Show()
        tre.Hide()
        ListBox2.Items.Add("")
        ListBox3.Items.Add("")
        ListBox4.Items.Add("")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If TextBox2.Text = "" Then
            If RadioButton5.Checked = True Then
                MsgBox(tre.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
            Else
                MsgBox(tre.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
            End If
        Else
            If TextBox3.Text = "" Then
                If RadioButton5.Checked = True Then
                    MsgBox(tre.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
                Else
                    MsgBox(tre.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
                End If
            Else
                If ComboBox3.Text = "" Then
                    If RadioButton5.Checked = True Then
                        MsgBox(tre.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
                    Else
                        MsgBox(tre.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
                    End If
                Else
                    If ListBox2.SelectedIndex = -1 Then
                    Else
                        If ListBox3.SelectedIndex = -1 Then
                        Else
                            If ListBox4.SelectedIndex = -1 Then
                            Else
                                ListBox2.Items.Insert(ListBox2.SelectedIndex, TextBox2.Text)
                                ListBox3.Items.Insert(ListBox3.SelectedIndex, TextBox3.Text)
                                ListBox4.Items.Insert(ListBox4.SelectedIndex, ComboBox3.Text)
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub LENG_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LENG.Tick
        If RadioButton4.Checked = True Then
            Label1.Text = "Posiciones X"
            Label2.Text = "Posiciones Y"
            Label3.Text = "Segundos"
            Label4.Text = "Eventos"
            Label5.Text = "Eventos"
            Label7.Text = "Posiciones Y"
            Label8.Text = "Posiciones X"
            Label9.Text = "Eventos"
            Label11.Text = "Posiciones Y"
            Label12.Text = "Posiciones X"


            Button1.Text = "Empezar"
            Button2.Text = "Detener"
            Button3.Text = "Agregar"
            Button4.Text = "Insertar"
            Button6.Text = "Cargar"
            Button7.Text = "Guardar"
            Button8.Text = "Cargar"
            Button9.Text = "Guardar"
            Button10.Text = "Cargar"
            Button11.Text = "Guardar"
            Button12.Text = "Limpiar"
            Button13.Text = "Eliminar"

            GroupBox1.Text = "Intervalo"
            GroupBox2.Text = "Gestionar Valores"
            GroupBox3.Text = "Guardar / Cargar Valores"
            GroupBox4.Text = "Reproducir"
            GroupBox5.Text = "Lenguaje"

            CheckBox1.Text = "Auto Detener"

            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("Sin Evento")
            ComboBox3.Items.Add("Click Izquierdo")
            ComboBox3.Items.Add("Click Derecho")
        End If

        If RadioButton5.Checked = True Then
            Label1.Text = "X Positions"
            Label2.Text = "Y Positions"
            Label3.Text = "Seconds"
            Label4.Text = "Events"
            Label5.Text = "Events"
            Label7.Text = "Y Positions"
            Label8.Text = "X Positions"
            Label9.Text = "Events"
            Label11.Text = "Y Positions"
            Label12.Text = "X Positions"


            Button1.Text = "Start"
            Button2.Text = "Stop"
            Button3.Text = "Add"
            Button4.Text = "Insert"
            Button6.Text = "Load"
            Button7.Text = "Save"
            Button8.Text = "Load"
            Button9.Text = "Save"
            Button10.Text = "Load"
            Button11.Text = "Save"
            Button12.Text = "Clear"
            Button13.Text = "Delete"

            GroupBox1.Text = "Interval"
            GroupBox2.Text = "Manage Values"
            GroupBox3.Text = "Save / Load Values"
            GroupBox4.Text = "Play"
            GroupBox5.Text = "Language"

            CheckBox1.Text = "Auto Stop"

            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("No Event")
            ComboBox3.Items.Add("Left Click")
            ComboBox3.Items.Add("Right Click")
        End If
    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click
        If RadioButton4.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        If RadioButton4.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub
End Class
