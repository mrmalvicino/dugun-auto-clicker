﻿Public Class tre

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Form1.RadioButton5.Checked = True Then
            TextBox5.Text = TextBox3.Text
        Else
            TextBox5.Text = TextBox4.Text
        End If
    End Sub
End Class