﻿Public Class Form1
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vkey As Long) As Integer
    Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Long, ByVal dx As Long, ByVal dy As Long, ByVal cButtons As Long, ByVal dwExtraInfo As Long)

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Timer1.Interval = TextBox3.Text * 1000
        Timer1.Start()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Stop()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If CheckBox1.Checked = True Then
            TextBox1.Enabled = True
            TextBox2.Enabled = True
        Else
            TextBox1.Enabled = False
            TextBox2.Enabled = False
        End If

        Dim ctrlkey As Boolean
        Dim x As Boolean
        Dim q As Boolean
        Dim w As Boolean
        ctrlkey = GetAsyncKeyState(Keys.ControlKey)
        x = GetAsyncKeyState(Keys.X)
        q = GetAsyncKeyState(Keys.Q)
        w = GetAsyncKeyState(Keys.W)

        If ctrlkey And q = True Then
            Timer1.Interval = TextBox3.Text * 1000
            Timer1.Start()
        End If

        If ctrlkey And w = True Then
            Timer1.Stop()
        End If

        If ctrlkey And x = True Then
            TextBox1.Text = Cursor.Position.X
            TextBox2.Text = Cursor.Position.Y
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If CheckBox1.Checked = True Then
            Windows.Forms.Cursor.Position = New System.Drawing.Point(TextBox1.Text, TextBox2.Text)
            mouse_event(&H2, 0, 0, 0, 1) 'el cursor se oprime (como un click)'
            mouse_event(&H4, 0, 0, 0, 1) 'el cursor se deja de oprimir'
        Else
            mouse_event(&H2, 0, 0, 0, 1) 'el cursor se oprime (como un click)'
            mouse_event(&H4, 0, 0, 0, 1) 'el cursor se deja de oprimir'
        End If
    End Sub

    Private Sub LANG_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LANG.Tick
        If RadioButton4.Checked = True Then
            Label2.Text = "Segundos"
            CheckBox1.Text = "Activar Posición"
            Button1.Text = "Empezar"
            Button2.Text = "Detener"
            GroupBox2.Text = "Posición"
            GroupBox3.Text = "Intervalo"
            GroupBox1.Text = "Comandos"
            GroupBox4.Text = "Lenguaje"
        End If

        If RadioButton5.Checked = True Then
            Label2.Text = "Seconds"
            CheckBox1.Text = "Activate Position"
            Button1.Text = "Start"
            Button2.Text = "Stop"
            GroupBox2.Text = "Position"
            GroupBox3.Text = "Interval"
            GroupBox1.Text = "Commands"
            GroupBox4.Text = "Language"
        End If
    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click
        If RadioButton4.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        If RadioButton4.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub
End Class
