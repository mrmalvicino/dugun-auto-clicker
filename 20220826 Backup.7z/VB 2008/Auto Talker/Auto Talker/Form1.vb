﻿Public Class Form1
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox1.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Timer2.Stop()
        Timer1.Stop()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Interval = TextBox3.Text * 1000
        Timer1.Start()

        If CheckBox2.Checked = True Then
            Timer2.Interval = TextBox2.Text * 60000
            Timer2.Start()
        End If


        If RadioButton4.Checked = True Then
            TextBox4.Text = ComboBox4.Text
        End If

        If RadioButton3.Checked = True Then
            TextBox4.Text = ComboBox3.Text
        End If

        If RadioButton2.Checked = True Then
            TextBox4.Text = ComboBox2.Text
        End If

        If RadioButton1.Checked = True Then
            TextBox4.Text = ComboBox1.Text
        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Timer1.Stop()
        Timer2.Stop()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If CheckBox3.Checked = False Then
            If CheckBox1.Checked = True Then
                SendKeys.Send(TextBox4.Text)
            End If
            SendKeys.Send(TextBox1.Text & "{ENTER}")
        Else
            If CheckBox1.Checked = True Then
                SendKeys.Send("{ENTER}" & TextBox4.Text)
            End If
            SendKeys.Send("{ENTER}" & TextBox1.Text & "{ENTER}")
        End If
    End Sub

    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        If RadioButton1.Checked = True Then
            ComboBox1.Enabled = True
        Else
            ComboBox1.Enabled = False
        End If

        If RadioButton2.Checked = True Then
            ComboBox2.Enabled = True
        Else
            ComboBox2.Enabled = False
        End If

        If RadioButton3.Checked = True Then
            ComboBox3.Enabled = True
        Else
            ComboBox3.Enabled = False
        End If

        If RadioButton4.Checked = True Then
            ComboBox4.Enabled = True
        Else
            ComboBox4.Enabled = False
        End If
    End Sub

    Private Sub LENG_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LENG.Tick
        If RadioButton5.Checked = True Then
            RadioButton1.Text = "Colores"
            RadioButton2.Text = "Movimientos"
            RadioButton3.Text = "Efectos"
            RadioButton4.Text = "Combinaciones"
            GroupBox1.Text = "Efectos de Texto"
            CheckBox1.Text = "Activar"
            CheckBox2.Text = "Activar"
            GroupBox4.Text = "Texto"
            GroupBox3.Text = "Intervalo"
            GroupBox2.Text = "Auto Detener"
            Label1.Text = "Minutos"
            Label2.Text = "Segundos"
            Button1.Text = "Detener"
            Button2.Text = "Empezar"
            Button3.Text = "Limpiar"
            GroupBox6.Text = "Comandos"
            GroupBox5.Text = "Lenguaje"
        End If

        If RadioButton6.Checked = True Then
            RadioButton1.Text = "Colours"
            RadioButton2.Text = "Movements"
            RadioButton3.Text = "Effects"
            RadioButton4.Text = "Combinations"
            GroupBox1.Text = "Text effects"
            CheckBox1.Text = "Activate"
            CheckBox2.Text = "Activate"
            GroupBox4.Text = "Text"
            GroupBox3.Text = "Interval"
            GroupBox2.Text = "Auto Stop"
            Label1.Text = "Minutes"
            Label2.Text = "Segundos"
            Button1.Text = "Stop"
            Button2.Text = "Start"
            Button3.Text = "Clean"
            GroupBox6.Text = "Commands"
            GroupBox5.Text = "Language"
        End If
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click
        If RadioButton5.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If

        If RadioButton6.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        If RadioButton5.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If

        If RadioButton6.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub
End Class
