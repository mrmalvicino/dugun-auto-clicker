﻿Public Class Form1
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vkey As Long) As Integer

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If RadioButton4.Checked = True Then
            GroupBox3.Text = "Marcadores"
            GroupBox4.Text = "Lenguaje"
        End If

        If RadioButton5.Checked = True Then
            GroupBox3.Text = "Marckers"
            GroupBox4.Text = "Language"
        End If

        Label1.Text = MousePosition.X
        Label2.Text = MousePosition.Y

        Dim ctrl As Boolean
        Dim a As Boolean
        Dim s As Boolean
        Dim d As Boolean
        Dim f As Boolean
        Dim g As Boolean

        ctrl = GetAsyncKeyState(Keys.ControlKey)
        a = GetAsyncKeyState(Keys.A)
        s = GetAsyncKeyState(Keys.S)
        d = GetAsyncKeyState(Keys.D)
        f = GetAsyncKeyState(Keys.F)
        g = GetAsyncKeyState(Keys.G)

        If ctrl And a = True Then
            TextBox1.Text = Label1.Text + "; " + Label2.Text
        End If

        If ctrl And s = True Then
            TextBox2.Text = Label1.Text + "; " + Label2.Text
        End If

        If ctrl And d = True Then
            TextBox3.Text = Label1.Text + "; " + Label2.Text
        End If

        If ctrl And f = True Then
            TextBox4.Text = Label1.Text + "; " + Label2.Text
        End If

        If ctrl And g = True Then
            TextBox5.Text = Label1.Text + "; " + Label2.Text
        End If

    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click
        If RadioButton4.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label8.Click
        If RadioButton4.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub
End Class
