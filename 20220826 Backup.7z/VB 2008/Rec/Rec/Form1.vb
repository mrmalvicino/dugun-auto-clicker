﻿Public Class Form1

    Private Declare Sub mouse_event Lib "user32" _
   (ByVal dwFlags As Integer, ByVal dx As Integer _
   , ByVal dy As Integer, ByVal cButtons As Integer _
   , ByVal dwExtraInfo As Integer)

    Private Const MOUSEEVENTF_LEFTDOWN = &H2
    Private Const MOUSEEVENTF_LEFTUP = &H4
    Private Const MOUSEEVENTF_RIGHTDOWN = &H8
    Private Const MOUSEEVENTF_RIGHTUP = &H10

    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer
    Private Const VK_LBUTTON = &H1
    Private Const VK_RBUTTON = &H2

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ListBox1.Items.Add(Cursor.Position.X)
        ListBox2.Items.Add(Cursor.Position.Y)

        If (GetAsyncKeyState(1)) Then
            ListBox3.Items.Add("Left Click")
        Else
            If (GetAsyncKeyState(2)) Then
                ListBox3.Items.Add("Right Click")
            Else
                ListBox3.Items.Add("No Event")
            End If
        End If

        ListBox1.SelectedIndex = ListBox1.SelectedIndex + 1
        ListBox2.SelectedIndex = ListBox2.SelectedIndex + 1
        ListBox3.SelectedIndex = ListBox3.SelectedIndex + 1
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Timer1.Start()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Enabled = False
        If Timer1.Enabled = True Then
            Timer1.Enabled = False
        Else

            If CheckBox2.Checked = True Then
            Else
                ListBox1.SelectedIndex = 1
                ListBox2.SelectedIndex = 1
                ListBox3.SelectedIndex = 1
            End If
            Button1.Enabled = True
            Button2.Enabled = True
            Button3.Enabled = True
            Button4.Enabled = True
            Button5.Enabled = True
            Button6.Enabled = True
            Button7.Enabled = True
            Button8.Enabled = True
            Button9.Enabled = True
            Button10.Enabled = True
            Button11.Enabled = True
            CheckBox1.Enabled = True
            CheckBox2.Enabled = True

        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ListBox1.SelectedIndex = 1
        ListBox2.SelectedIndex = 1
        ListBox3.SelectedIndex = 1
        Timer2.Start()

        Button1.Enabled = False
        Button2.Enabled = False
        Button3.Enabled = False
        Button4.Enabled = True
        Button5.Enabled = False
        Button6.Enabled = False
        Button7.Enabled = False
        Button8.Enabled = False
        Button9.Enabled = False
        Button10.Enabled = False
        Button11.Enabled = False
        CheckBox1.Enabled = False
        CheckBox2.Enabled = False
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 = True Then
            If CheckBox1.Checked = True Then
                Timer2.Stop()
            Else
                ListBox1.SelectedIndex = 1
                ListBox2.SelectedIndex = 1
                ListBox3.SelectedIndex = 1
            End If
        Else
            ListBox1.SelectedIndex = ListBox1.SelectedIndex + 1
            ListBox2.SelectedIndex = ListBox2.SelectedIndex + 1
            ListBox3.SelectedIndex = ListBox3.SelectedIndex + 1

            Cursor.Position = New Point(ListBox1.SelectedItem, ListBox2.SelectedItem)

            If ListBox3.SelectedItem = "Left Click" Then
                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
            End If

            If ListBox3.SelectedItem = "Right Click" Then
                mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)
                mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
            End If

        End If


    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Timer2.Stop()

        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True
        Button5.Enabled = True
        Button6.Enabled = True
        Button7.Enabled = True
        Button8.Enabled = True
        Button9.Enabled = True
        Button10.Enabled = True
        Button11.Enabled = True
        CheckBox1.Enabled = True
        CheckBox2.Enabled = True
        
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If CheckBox2.Checked = True Then
        Else
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()
            ListBox3.Items.Clear()
        End If

        Timer1.Start()

        Button1.Enabled = False
        Button2.Enabled = True
        Button3.Enabled = False
        Button4.Enabled = False
        Button5.Enabled = False
        Button6.Enabled = False
        Button7.Enabled = False
        Button8.Enabled = False
        Button9.Enabled = False
        Button10.Enabled = False
        Button11.Enabled = False
        CheckBox1.Enabled = False
        CheckBox2.Enabled = False
        

    End Sub

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ListBox1.Items.Clear()

        Dim Name As String
        OpenFileDialog1.Filter = ""
        OpenFileDialog1.FilterIndex = 2
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.FileName = OpenFileDialog1.FileName
        FileOpen(3, OpenFileDialog1.FileName, OpenMode.Input)
        Do While Not EOF(3)
            Name = LineInput(3)
            If LEN(Trim(Name)) > 0 Then
                ListBox1.Items.Add(Trim(Name))
            End If
        Loop
        FileClose(3)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox1.Items.Count - 1
                            StreamW.WriteLine(ListBox1.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox1.Items.Count - 1
                        StreamW.WriteLine(ListBox1.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox1.Items.Count - 1
                            StreamW.WriteLine(ListBox1.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox1.Items.Count - 1
                        StreamW.WriteLine(ListBox1.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox1.Items.Count - 1
                            StreamW.WriteLine(ListBox1.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox1.Items.Count - 1
                        StreamW.WriteLine(ListBox1.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\1.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\1.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                        For i = 0 To ListBox1.Items.Count - 1
                            StreamW.WriteLine(ListBox1.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\1.txt")
                    For i = 0 To ListBox1.Items.Count - 1
                        StreamW.WriteLine(ListBox1.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        End If

    End Sub

    Private Sub Button8_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        ListBox2.Items.Clear()

        Dim Name As String
        OpenFileDialog1.Filter = ""
        OpenFileDialog1.FilterIndex = 2
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.FileName = OpenFileDialog1.FileName
        FileOpen(3, OpenFileDialog1.FileName, OpenMode.Input)
        Do While Not EOF(3)
            Name = LineInput(3)
            If Len(Trim(Name)) > 0 Then
                ListBox2.Items.Add(Trim(Name))
            End If
        Loop
        FileClose(3)
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        ListBox3.Items.Clear()

        Dim Name As String
        OpenFileDialog1.Filter = ""
        OpenFileDialog1.FilterIndex = 2
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.FileName = OpenFileDialog1.FileName
        FileOpen(3, OpenFileDialog1.FileName, OpenMode.Input)
        Do While Not EOF(3)
            Name = LineInput(3)
            If Len(Trim(Name)) > 0 Then
                ListBox3.Items.Add(Trim(Name))
            End If
        Loop
        FileClose(3)
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\2.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\2.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                        For i = 0 To ListBox2.Items.Count - 1
                            StreamW.WriteLine(ListBox2.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\2.txt")
                    For i = 0 To ListBox2.Items.Count - 1
                        StreamW.WriteLine(ListBox2.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")

                If System.IO.File.Exists("C:\Dugun\Saved Settings\3.txt") Then
                    Dim ask As MsgBoxResult
                    ask = MsgBox(er.TextBox5.Text, MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Settings\3.txt")
                        Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                        For i = 0 To ListBox3.Items.Count - 1
                            StreamW.WriteLine(ListBox3.Items.Item(i))
                        Next
                        StreamW.Close()
                        StreamW.Dispose()
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    Dim StreamW As New IO.StreamWriter("C:\Dugun\Saved Settings\3.txt")
                    For i = 0 To ListBox3.Items.Count - 1
                        StreamW.WriteLine(ListBox3.Items.Item(i))
                    Next
                    StreamW.Close()
                    StreamW.Dispose()
                End If

            End If
        End If
    End Sub

    Private Sub hot_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles hot.Tick

        Dim ctrlkey As Boolean
        Dim m As Boolean
        Dim q As Boolean
        Dim w As Boolean
        Dim r As Boolean

        ctrlkey = GetAsyncKeyState(Keys.ControlKey)
        m = GetAsyncKeyState(Keys.E)
        q = GetAsyncKeyState(Keys.Q)
        w = GetAsyncKeyState(Keys.W)
        r = GetAsyncKeyState(Keys.R)


        
        If ctrlkey And q = True Then
            ListBox1.SelectedIndex = 1
            ListBox2.SelectedIndex = 1
            ListBox3.SelectedIndex = 1
            Timer2.Start()
            Button1.Enabled = False
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Enabled = True
            Button5.Enabled = False
            Button6.Enabled = False
            Button7.Enabled = False
            Button8.Enabled = False
            Button9.Enabled = False
            Button10.Enabled = False
            Button11.Enabled = False
            CheckBox1.Enabled = False
            CheckBox2.Enabled = False
        End If

        If ctrlkey And w = True Then
            Timer2.Stop()
            Button1.Enabled = True
            Button2.Enabled = True
            Button3.Enabled = True
            Button4.Enabled = True
            Button5.Enabled = True
            Button6.Enabled = True
            Button7.Enabled = True
            Button8.Enabled = True
            Button9.Enabled = True
            Button10.Enabled = True
            Button11.Enabled = True
            CheckBox1.Enabled = True
            CheckBox2.Enabled = True
        End If


        If ctrlkey And m = True Then
            If CheckBox2.Checked = True Then
            Else
                ListBox1.Items.Clear()
                ListBox2.Items.Clear()
                ListBox3.Items.Clear()
            End If
            Timer1.Start()
            Button1.Enabled = False
            Button2.Enabled = True
            Button3.Enabled = False
            Button4.Enabled = False
            Button5.Enabled = False
            Button6.Enabled = False
            Button7.Enabled = False
            Button8.Enabled = False
            Button9.Enabled = False
            Button10.Enabled = False
            Button11.Enabled = False
            CheckBox1.Enabled = False
            CheckBox2.Enabled = False
        End If

        If ctrlkey And r = True Then
            Timer1.Stop()
            If CheckBox2.Checked = True Then
            Else
                ListBox1.SelectedIndex = 1
                ListBox2.SelectedIndex = 1
                ListBox3.SelectedIndex = 1
            End If
            Button1.Enabled = True
            Button2.Enabled = True
            Button3.Enabled = True
            Button4.Enabled = True
            Button5.Enabled = True
            Button6.Enabled = True
            Button7.Enabled = True
            Button8.Enabled = True
            Button9.Enabled = True
            Button10.Enabled = True
            Button11.Enabled = True
            CheckBox1.Enabled = True
            CheckBox2.Enabled = True
        End If

    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        If ListBox1.SelectedIndex = -1 Then
        Else
            If RadioButton1.Checked = True Then
                ListBox1.Items.Insert(ListBox1.SelectedIndex, TextBox1.Text)
            End If
        End If

        If ListBox2.SelectedIndex = -1 Then
        Else
            If RadioButton2.Checked = True Then
                ListBox2.Items.Insert(ListBox2.SelectedIndex, TextBox1.Text)
            End If
        End If

        If ListBox3.SelectedIndex = -1 Then
        Else
            If RadioButton3.Checked = True Then
                ListBox3.Items.Insert(ListBox3.SelectedIndex, TextBox1.Text)
            End If
        End If

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        If ListBox1.SelectedIndex = -1 Then
        Else
            If RadioButton1.Checked = True Then
                ListBox1.Items.RemoveAt(ListBox1.SelectedIndex)
            End If
        End If

        If ListBox2.SelectedIndex = -1 Then
        Else
            If RadioButton2.Checked = True Then
                ListBox2.Items.RemoveAt(ListBox2.SelectedIndex)
            End If
        End If

        If ListBox3.SelectedIndex = -1 Then
        Else
            If RadioButton3.Checked = True Then
                ListBox3.Items.RemoveAt(ListBox3.SelectedIndex)
            End If
        End If

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        If RadioButton4.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        If RadioButton4.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton5.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub LEN_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LENG.Tick
        If RadioButton4.Checked = True Then
            Label1.Text = "Posiciones X"
            Label2.Text = "Posiciones Y"
            Label4.Text = "Eventos"
            Label9.Text = "Eventos"
            Label11.Text = "Posiciones Y"
            Label12.Text = "Posiciones X"

            Button1.Text = "Empezar"
            Button2.Text = "Detener"
            Button3.Text = "Empezar"
            Button4.Text = "Detener"
            Button5.Text = "Guardar"
            Button6.Text = "Cargar"
            Button7.Text = "Guardar"
            Button8.Text = "Cargar"
            Button9.Text = "Guardar"
            Button10.Text = "Cargar"
            Button11.Text = "Insertar"
            Button12.Text = "Eliminar Seleccionado"

            GroupBox1.Text = "Grabar"
            GroupBox2.Text = "Reproducir"
            GroupBox3.Text = "Gestionar Valores"
            GroupBox4.Text = "Guardar / Cargar Valores"
            GroupBox5.Text = "Lenguaje"

            CheckBox1.Text = "Auto Detener"
            CheckBox2.Text = "Seguir Grabando"
        End If

        If RadioButton5.Checked = True Then
            Label1.Text = "X Positions"
            Label2.Text = "Y Positions"
            Label4.Text = "Events"
            Label9.Text = "Events"
            Label11.Text = "Y Positions"
            Label12.Text = "X Positions"

            Button1.Text = "Start"
            Button2.Text = "Stop"
            Button3.Text = "Start"
            Button4.Text = "Stop"
            Button5.Text = "Save"
            Button6.Text = "Load"
            Button7.Text = "Save"
            Button8.Text = "Load"
            Button9.Text = "Save"
            Button10.Text = "Load"
            Button11.Text = "Insert"
            Button12.Text = "Delete Selected"

            GroupBox1.Text = "Record"
            GroupBox2.Text = "Play"
            GroupBox3.Text = "Manage Values"
            GroupBox4.Text = "Save / Load Values"
            GroupBox5.Text = "Language"

            CheckBox1.Text = "Auto Stop"
            CheckBox2.Text = "Continue Recording"
        End If
    End Sub

End Class
