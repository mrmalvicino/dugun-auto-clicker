﻿Public Class t

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If principal.RadioButton1.Checked = True Then
            TextBox2.Text = "Ninguna acción seleccionada"
            TextBox1.Text = "El plugin fue eliminado recientemente, no se encuentra mas en el directorio C:\Dugun\Plugins\ , o el directorio no existe mas."
        End If
        If principal.RadioButton2.Checked = True Then
            TextBox2.Text = "No action selected"
            TextBox1.Text = "The plugin has been deleted recently. The plugin is not anymore in the directory C:\Dugun\Plugins\. The directory does not exists anymore."
        End If
    End Sub
End Class