﻿Public Class principal

    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vkey As Long) As Integer

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        If CheckBox1.Checked = False Then
            Button2.Enabled = False
            Button3.Enabled = False
            TextBox2.Enabled = False
            ComboBox3.Enabled = False
            Timer3.Enabled = False

        End If

        If CheckBox1.Checked = True Then
            Button2.Enabled = True
            Button3.Enabled = True
            TextBox2.Enabled = True
            ComboBox3.Enabled = True
        End If

        Label5.Text = TimeOfDay

        If ComboBox1.Text = "1" Then
            TextBox1.Text = "0"
        End If

        If ComboBox1.Text = "2" Then
            TextBox1.Text = "83"
        End If

        If ComboBox1.Text = "3" Then
            TextBox1.Text = "174"
        End If

        If ComboBox1.Text = "4" Then
            TextBox1.Text = "276"
        End If

        If ComboBox1.Text = "5" Then
            TextBox1.Text = "388"
        End If

        If ComboBox1.Text = "6" Then
            TextBox1.Text = "512"
        End If

        If ComboBox1.Text = "7" Then
            TextBox1.Text = "650"
        End If

        If ComboBox1.Text = "8" Then
            TextBox1.Text = "801"
        End If

        If ComboBox1.Text = "9" Then
            TextBox1.Text = "969"
        End If

        If ComboBox1.Text = "10" Then
            TextBox1.Text = "1154"
        End If

        If ComboBox1.Text = "11" Then
            TextBox1.Text = "1358"
        End If

        If ComboBox1.Text = "12" Then
            TextBox1.Text = "1584"
        End If

        If ComboBox1.Text = "13" Then
            TextBox1.Text = "1833"
        End If

        If ComboBox1.Text = "14" Then
            TextBox1.Text = "2107"
        End If

        If ComboBox1.Text = "15" Then
            TextBox1.Text = "2411"
        End If

        If ComboBox1.Text = "16" Then
            TextBox1.Text = "2746"
        End If

        If ComboBox1.Text = "17" Then
            TextBox1.Text = "3115"
        End If

        If ComboBox1.Text = "18" Then
            TextBox1.Text = "3523"
        End If

        If ComboBox1.Text = "19" Then
            TextBox1.Text = "3973"
        End If

        If ComboBox1.Text = "20" Then
            TextBox1.Text = "4470"
        End If

        If ComboBox1.Text = "21" Then
            TextBox1.Text = "5018"
        End If

        If ComboBox1.Text = "22" Then
            TextBox1.Text = "5624"
        End If

        If ComboBox1.Text = "23" Then
            TextBox1.Text = "6291"
        End If

        If ComboBox1.Text = "24" Then
            TextBox1.Text = "7028"
        End If

        If ComboBox1.Text = "25" Then
            TextBox1.Text = "7842"
        End If

        If ComboBox1.Text = "26" Then
            TextBox1.Text = "8740"
        End If

        If ComboBox1.Text = "27" Then
            TextBox1.Text = "9730"
        End If

        If ComboBox1.Text = "28" Then
            TextBox1.Text = "10824"
        End If

        If ComboBox1.Text = "29" Then
            TextBox1.Text = "12031"
        End If

        If ComboBox1.Text = "30" Then
            TextBox1.Text = "13363"
        End If

        If ComboBox1.Text = "31" Then
            TextBox1.Text = "14833"
        End If

        If ComboBox1.Text = "32" Then
            TextBox1.Text = "16456"
        End If

        If ComboBox1.Text = "33" Then
            TextBox1.Text = "18247"
        End If

        If ComboBox1.Text = "34" Then
            TextBox1.Text = "20224"
        End If

        If ComboBox1.Text = "35" Then
            TextBox1.Text = "22406"
        End If

        If ComboBox1.Text = "36" Then
            TextBox1.Text = "24815"
        End If

        If ComboBox1.Text = "37" Then
            TextBox1.Text = "27473"
        End If

        If ComboBox1.Text = "38" Then
            TextBox1.Text = "30408"
        End If

        If ComboBox1.Text = "39" Then
            TextBox1.Text = "33648"
        End If

        If ComboBox1.Text = "40" Then
            TextBox1.Text = "37224"
        End If

        If ComboBox1.Text = "41" Then
            TextBox1.Text = "41171"
        End If

        If ComboBox1.Text = "42" Then
            TextBox1.Text = "45529"
        End If

        If ComboBox1.Text = "43" Then
            TextBox1.Text = "50339"
        End If

        If ComboBox1.Text = "44" Then
            TextBox1.Text = "55649"
        End If

        If ComboBox1.Text = "45" Then
            TextBox1.Text = "61512"
        End If

        If ComboBox1.Text = "46" Then
            TextBox1.Text = "67983"
        End If

        If ComboBox1.Text = "47" Then
            TextBox1.Text = "45127"
        End If

        If ComboBox1.Text = "48" Then
            TextBox1.Text = "83014"
        End If

        If ComboBox1.Text = "49" Then
            TextBox1.Text = "91721"
        End If

        If ComboBox1.Text = "50" Then
            TextBox1.Text = "101333"
        End If

        If ComboBox1.Text = "51" Then
            TextBox1.Text = "111945"
        End If

        If ComboBox1.Text = "52" Then
            TextBox1.Text = "123660"
        End If

        If ComboBox1.Text = "53" Then
            TextBox1.Text = "136594"
        End If

        If ComboBox1.Text = "54" Then
            TextBox1.Text = "150872"
        End If

        If ComboBox1.Text = "55" Then
            TextBox1.Text = "166636"
        End If

        If ComboBox1.Text = "56" Then
            TextBox1.Text = "184040"
        End If

        If ComboBox1.Text = "57" Then
            TextBox1.Text = "203254"
        End If

        If ComboBox1.Text = "58" Then
            TextBox1.Text = "224466"
        End If

        If ComboBox1.Text = "59" Then
            TextBox1.Text = "247886"
        End If

        If ComboBox1.Text = "60" Then
            TextBox1.Text = "273742"
        End If

        If ComboBox1.Text = "61" Then
            TextBox1.Text = "302288"
        End If

        If ComboBox1.Text = "62" Then
            TextBox1.Text = "333804"
        End If

        If ComboBox1.Text = "63" Then
            TextBox1.Text = "368599"
        End If

        If ComboBox1.Text = "64" Then
            TextBox1.Text = "407015"
        End If

        If ComboBox1.Text = "65" Then
            TextBox1.Text = "449428"
        End If

        If ComboBox1.Text = "66" Then
            TextBox1.Text = "496254"
        End If

        If ComboBox1.Text = "67" Then
            TextBox1.Text = "547953"
        End If

        If ComboBox1.Text = "68" Then
            TextBox1.Text = "605032"
        End If

        If ComboBox1.Text = "69" Then
            TextBox1.Text = "668051"
        End If

        If ComboBox1.Text = "70" Then
            TextBox1.Text = "737627"
        End If

        If ComboBox1.Text = "71" Then
            TextBox1.Text = "814445"
        End If

        If ComboBox1.Text = "72" Then
            TextBox1.Text = "899257"
        End If

        If ComboBox1.Text = "73" Then
            TextBox1.Text = "992895"
        End If

        If ComboBox1.Text = "74" Then
            TextBox1.Text = "1096278"
        End If

        If ComboBox1.Text = "75" Then
            TextBox1.Text = "1210421"
        End If

        If ComboBox1.Text = "76" Then
            TextBox1.Text = "1336443"
        End If

        If ComboBox1.Text = "77" Then
            TextBox1.Text = "1475581"
        End If

        If ComboBox1.Text = "78" Then
            TextBox1.Text = "1629200"
        End If

        If ComboBox1.Text = "79" Then
            TextBox1.Text = "1798808"
        End If

        If ComboBox1.Text = "80" Then
            TextBox1.Text = "1986068"
        End If

        If ComboBox1.Text = "81" Then
            TextBox1.Text = "2192818"
        End If

        If ComboBox1.Text = "82" Then
            TextBox1.Text = "2421087"
        End If

        If ComboBox1.Text = "83" Then
            TextBox1.Text = "2673114"
        End If

        If ComboBox1.Text = "84" Then
            TextBox1.Text = "2951373"
        End If

        If ComboBox1.Text = "85" Then
            TextBox1.Text = "3258594"
        End If

        If ComboBox1.Text = "86" Then
            TextBox1.Text = "3597972"
        End If

        If ComboBox1.Text = "87" Then
            TextBox1.Text = "3972294"
        End If

        If ComboBox1.Text = "88" Then
            TextBox1.Text = "4385776"
        End If

        If ComboBox1.Text = "89" Then
            TextBox1.Text = "4842295"
        End If

        If ComboBox1.Text = "90" Then
            TextBox1.Text = "5346332"
        End If

        If ComboBox1.Text = "91" Then
            TextBox1.Text = "5902831"
        End If

        If ComboBox1.Text = "92" Then
            TextBox1.Text = "6517253"
        End If

        If ComboBox1.Text = "93" Then
            TextBox1.Text = "7195629"
        End If

        If ComboBox1.Text = "94" Then
            TextBox1.Text = "7944614"
        End If

        If ComboBox1.Text = "95" Then
            TextBox1.Text = "8771558"
        End If

        If ComboBox1.Text = "96" Then
            TextBox1.Text = "9684577"
        End If

        If ComboBox1.Text = "97" Then
            TextBox1.Text = "10692629"
        End If

        If ComboBox1.Text = "98" Then
            TextBox1.Text = "11805606"
        End If

        If ComboBox1.Text = "99" Then
            TextBox1.Text = "13034431"
        End If
    End Sub

    Private Sub Button1_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ComboBox2.Text = "n/a" Then
            MsgBox(t.TextBox2.Text, MsgBoxStyle.Critical, "Dugun")
        End If

        If ComboBox2.Text = "+" Then
            TextBox7.Text = Val(TextBox5.Text) + Val(TextBox6.Text)
        End If

        If ComboBox2.Text = "-" Then
            TextBox7.Text = Val(TextBox5.Text) - Val(TextBox6.Text)
        End If

        If ComboBox2.Text = "x" Then
            TextBox7.Text = Val(TextBox5.Text) * Val(TextBox6.Text)
        End If

        If ComboBox2.Text = "/" Then
            TextBox7.Text = Val(TextBox5.Text) / Val(TextBox6.Text)
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TextBox10.Text = ""
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Notes") Then

                If System.IO.File.Exists("C:\Dugun\Saved Notes\Note.txt") Then

                    If RadioButton1.Checked = True Then
                        Dim ask As MsgBoxResult
                        ask = MsgBox("El archivo ya existe. ¿Desea reemplazarlo?", MsgBoxStyle.YesNo, "Dugun")
                        If ask = MsgBoxResult.Yes Then
                            System.IO.File.Delete("C:\Dugun\Saved Notes\Note.txt")
                            Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                            wu.Write(TextBox10.Text)
                            wu.Close()
                        End If
                        If ask = MsgBoxResult.No Then
                        End If
                    End If

                    If RadioButton2.Checked = True Then
                        Dim ask As MsgBoxResult
                        ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")
                        If ask = MsgBoxResult.Yes Then
                            System.IO.File.Delete("C:\Dugun\Saved Notes\Note.txt")
                            Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                            wu.Write(TextBox10.Text)
                            wu.Close()
                        End If
                        If ask = MsgBoxResult.No Then
                        End If
                    End If

                Else
                    Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                    wu.Write(TextBox10.Text)
                    wu.Close()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Notes")

                If System.IO.File.Exists("C:\Dugun\Saved Notes\Note.txt") Then

                    Dim ask As MsgBoxResult
                    ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")
                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Notes\Note.txt")
                        Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                        wu.Write(TextBox10.Text)
                        wu.Close()
                    End If
                    If ask = MsgBoxResult.No Then
                    End If
                Else
                    Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                    wu.Write(TextBox10.Text)
                    wu.Close()
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Notes") Then

                If System.IO.File.Exists("C:\Dugun\Saved Notes\Note.txt") Then

                    Dim ask As MsgBoxResult
                    ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")
                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Notes\Note.txt")
                        Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                        wu.Write(TextBox10.Text)
                        wu.Close()
                    End If
                    If ask = MsgBoxResult.No Then
                    End If
                Else
                    Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                    wu.Write(TextBox10.Text)
                    wu.Close()
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Notes")

                If System.IO.File.Exists("C:\Dugun\Saved Notes\Note.txt") Then

                    Dim ask As MsgBoxResult
                    ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")
                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Notes\Note.txt")
                        Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                        wu.Write(TextBox10.Text)
                        wu.Close()
                    End If
                    If ask = MsgBoxResult.No Then
                    End If
                Else
                    Dim wu As New System.IO.StreamWriter("C:\Dugun\Saved Notes\Note.txt")
                    wu.Write(TextBox10.Text)
                    wu.Close()
                End If

            End If
        End If

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Button7.Enabled = True
        Timer2.Start()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim bounds As Rectangle
        Dim screenshot As System.Drawing.Bitmap
        Dim graph As Graphics
        bounds = Screen.PrimaryScreen.Bounds
        screenshot = New System.Drawing.Bitmap(bounds.Width, bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
        graph = Graphics.FromImage(screenshot)
        graph.CopyFromScreen(bounds.X, bounds.Y, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy)
        PictureBox1.Image = screenshot
        Timer2.Stop()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Screenshots") Then

                If System.IO.File.Exists("C:\Dugun\Saved Screenshots\Screenshot.bmp") Then

                    If RadioButton1.Checked = True Then
                        Dim ask As MsgBoxResult
                        ask = MsgBox("El archivo ya existe. ¿Desea reemplazarlo?", MsgBoxStyle.YesNo, "Dugun")
                        If ask = MsgBoxResult.Yes Then
                            System.IO.File.Delete("C:\Dugun\Saved Screenshots\Screenshot.bmp")
                            PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                        End If
                        If ask = MsgBoxResult.No Then
                        End If
                    End If

                    If RadioButton2.Checked = True Then
                        Dim ask As MsgBoxResult
                        ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")
                        If ask = MsgBoxResult.Yes Then
                            System.IO.File.Delete("C:\Dugun\Saved Screenshots\Screenshot.bmp")
                            PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                        End If
                        If ask = MsgBoxResult.No Then
                        End If
                    End If

                Else
                    PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Screenshots")

                If System.IO.File.Exists("C:\Dugun\Saved Screenshots\Screenshot.bmp") Then

                    Dim ask As MsgBoxResult
                    ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Screenshots\Screenshot.bmp")
                        PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                End If

            End If
        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
            If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Screenshots") Then

                If System.IO.File.Exists("C:\Dugun\Saved Screenshots\Screenshot.bmp") Then

                    Dim ask As MsgBoxResult
                    ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Screenshots\Screenshot.bmp")
                        PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                End If

            Else
                My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Screenshots")

                If System.IO.File.Exists("C:\Dugun\Saved Screenshots\Screenshot.bmp") Then

                    Dim ask As MsgBoxResult
                    ask = MsgBox("The file already exists. Do you want to overwrite it?", MsgBoxStyle.YesNo, "Dugun")

                    If ask = MsgBoxResult.Yes Then
                        System.IO.File.Delete("C:\Dugun\Saved Screenshots\Screenshot.bmp")
                        PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                    End If

                    If ask = MsgBoxResult.No Then
                    End If

                Else
                    PictureBox1.Image.Save("C:\Dugun\Saved Screenshots\Screenshot.bmp", System.Drawing.Imaging.ImageFormat.Bmp)
                End If

            End If
        End If

    End Sub

    Private Sub BasesYCondicionesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BasesYCondicionesToolStripMenuItem.Click
        If RadioButton1.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton2.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub AcercaDeDugunToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AcercaDeDugunToolStripMenuItem.Click
        If RadioButton1.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton2.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub CreateDugunFoldersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateDugunFoldersToolStripMenuItem.Click
        If My.Computer.FileSystem.DirectoryExists("C:\Dugun") Then

        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun")
        End If

        If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Notes") Then

        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Notes")
        End If

        If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Screenshots") Then

        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Screenshots")
        End If

        If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Saved Settings") Then

        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun\Saved Settings")
        End If

        If My.Computer.FileSystem.DirectoryExists("C:\Dugun\Plugins") Then

        Else
            My.Computer.FileSystem.CreateDirectory("C:\Dugun\Plugins")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ComboBox3.Text = "M" Then
            Timer3.Interval = 60000
        End If
        If ComboBox3.Text = "S" Then
            Timer3.Interval = 1000
        End If
        If ComboBox3.Text = "H" Then
            Timer3.Interval = 3600000
        End If

        If ComboBox3.Text = "M" Then
            Timer3.Interval = 60000
        End If
        If ComboBox3.Text = "S" Then
            Timer3.Interval = 1000
        End If
        If ComboBox3.Text = "H" Then
            Timer3.Interval = 3600000
        End If

        TextBox2.Text = "0"
        Timer3.Enabled = True
    End Sub

    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        TextBox2.Text = Val(TextBox2.Text) + 1
    End Sub

    Private Sub RestartLocationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestartLocationToolStripMenuItem.Click
        CenterToScreen()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub

    Private Sub ToolsBarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolsBarToolStripMenuItem.Click
        Panel1.Visible = True
    End Sub

    Private Sub DugunToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DugunToolStripMenuItem.Click
        WebBrowser1.Navigate("http://www.dugun.webstarts.com")
    End Sub

    Private Sub RuneScapeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RuneScapeToolStripMenuItem.Click
        WebBrowser1.Navigate("http://www.runescape.com")
    End Sub

    Private Sub principal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        t.Show()
        t.Hide()
        WebBrowser1.Navigate("http://www.dugun.webstarts.com")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox2.Text = "0"
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        TextBox2.Text = "0"
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        ComboBox1.Text = TextBox9.Text
    End Sub

    Private Sub GestionarPluginsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GestionarPluginsToolStripMenuItem.Click
        opt.Show()
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        Panel1.Visible = False
    End Sub

    Private Sub AutoClickerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutoClickerToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Auto Clicker.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Auto Clicker.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub MacroClickerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MacroClickerToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Macro Clicker.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Macro Clicker.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub AntiBanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AntiBanToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Anti Ban.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Anti Ban.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub AutoTalkerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutoTalkerToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Auto Talker.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Auto Talker.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub RecToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RecToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Rec.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Rec.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub DugunReyClickerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DugunReyClickerToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Rey Clicker.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Rey Clicker.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub DugunRuneScapeCallerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DugunRuneScapeCallerToolStripMenuItem.Click
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Caller.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Caller.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub DugunRuneScapeStudioToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Studio.exe") Then
            Shell("C:\Dugun\Plugins\Dugun Studio.exe")
        Else
            MsgBox(t.TextBox1.Text, MsgBoxStyle.Critical, "Dugun")
        End If
    End Sub

    Private Sub LEN_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEN.Tick
        If RadioButton1.Checked = True Then
            Button6.Text = "Tomar Foto"
            Button7.Text = "Guardar"
            Button4.Text = "Ir"
            Button8.Text = "Limpiar"
            Button9.Text = "Guardar"
            Button2.Text = "Contar"
            Button3.Text = "Limpiar"
            opt.Button1.Text = "Hecho"
            CheckBox1.Text = "Tiempo Jugando"

            GroupBox9.Text = "Reloj"
            GroupBox4.Text = "Nota"
            GroupBox8.Text = "Tabla de XP"
            GroupBox5.Text = "Calculadora"

            Label1.Text = "Ir a:"

            opt.Text = "Agregar Plugins"

            ArchivoToolStripMenuItem.Text = "Archivo"
            CreateDugunFoldersToolStripMenuItem.Text = "Crear carpetas de Dugun"
            ToolsBarToolStripMenuItem.Text = "Mostrar Barra de Herramientas"
            ExitToolStripMenuItem.Text = "Salir"
            GestionarPluginsToolStripMenuItem.Text = "Agregar Plugins"
        End If

        If RadioButton2.Checked = True Then
            Button6.Text = "Take Photo"
            Button7.Text = "Save"
            Button4.Text = "Go"
            Button8.Text = "Clean"
            Button9.Text = "Save"
            Button2.Text = "Count"
            Button3.Text = "Clean"
            opt.Button1.Text = "Done"

            CheckBox1.Text = "Time Playing"

            GroupBox9.Text = "Clock"
            GroupBox4.Text = "Note"
            GroupBox8.Text = "XP Table"
            GroupBox5.Text = "Calculator"

            Label1.Text = "Go to:"

            opt.Text = "Add Plugins"

            ArchivoToolStripMenuItem.Text = "File"
            CreateDugunFoldersToolStripMenuItem.Text = "Create Dugun Folders"
            ToolsBarToolStripMenuItem.Text = "Show Tools Bar"
            ExitToolStripMenuItem.Text = "Exit"
            GestionarPluginsToolStripMenuItem.Text = "Add Plugins"
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        WebBrowser1.Navigate("http://www.runescape.com/game.ws")
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        WebBrowser1.Navigate("http://www.runescape.com/l=6/game.ws")
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        WebBrowser1.Navigate("http://oldschool.runescape.com/")
    End Sub
End Class
