﻿Public Class opt

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Anti Ban.exe") Then
            CheckBox1.Enabled = True
        Else
            CheckBox1.Enabled = False
            CheckBox1.Checked = False
        End If
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Auto Clicker.exe") Then
            CheckBox2.Enabled = True
        Else
            CheckBox2.Enabled = False
            CheckBox2.Checked = False
        End If
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Auto Talker.exe") Then
            CheckBox3.Enabled = True
        Else
            CheckBox3.Enabled = False
            CheckBox3.Checked = False
        End If
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Macro Clicker.exe") Then
            CheckBox4.Enabled = True
        Else
            CheckBox4.Enabled = False
            CheckBox4.Checked = False
        End If
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Rec.exe") Then
            CheckBox5.Enabled = True
        Else
            CheckBox5.Enabled = False
            CheckBox5.Checked = False
        End If
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Rey Clicker.exe") Then
            CheckBox7.Enabled = True
        Else
            CheckBox7.Enabled = False
            CheckBox7.Checked = False
        End If
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Caller.exe") Then
            CheckBox6.Enabled = True
        Else
            CheckBox6.Enabled = False
            CheckBox6.Checked = False
        End If
        
        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun XY Screen.exe") Then
            CheckBox9.Enabled = True
        Else
            CheckBox9.Enabled = False
            CheckBox9.Checked = False
        End If

        If My.Computer.FileSystem.FileExists("C:\Dugun\Plugins\Dugun Shutdown Manager.exe") Then
            CheckBox10.Enabled = True
        Else
            CheckBox10.Enabled = False
            CheckBox10.Checked = False
        End If



        If CheckBox1.Checked = True Then
            principal.AntiBanToolStripMenuItem.Visible = True
        Else
            principal.AntiBanToolStripMenuItem.Visible = False
        End If

        If CheckBox2.Checked = True Then
            principal.AutoClickerToolStripMenuItem.Visible = True
        Else
            principal.AutoClickerToolStripMenuItem.Visible = False
        End If

        If CheckBox3.Checked = True Then
            principal.AutoTalkerToolStripMenuItem.Visible = True
        Else
            principal.AutoTalkerToolStripMenuItem.Visible = False
        End If

        If CheckBox4.Checked = True Then
            principal.MacroClickerToolStripMenuItem.Visible = True
        Else
            principal.MacroClickerToolStripMenuItem.Visible = False
        End If

        If CheckBox5.Checked = True Then
            principal.RecToolStripMenuItem.Visible = True
        Else
            principal.RecToolStripMenuItem.Visible = False
        End If

        If CheckBox7.Checked = True Then
            principal.DugunReyClickerToolStripMenuItem.Visible = True
        Else
            principal.DugunReyClickerToolStripMenuItem.Visible = False
        End If

        If CheckBox6.Checked = True Then
            principal.DugunRuneScapeCallerToolStripMenuItem.Visible = True
        Else
            principal.DugunRuneScapeCallerToolStripMenuItem.Visible = False
        End If

        If CheckBox9.Checked = True Then
            principal.DugunXYScreenToolStripMenuItem.Visible = True
        Else
            principal.DugunXYScreenToolStripMenuItem.Visible = False
        End If

        If CheckBox10.Checked = True Then
            principal.DugunShutdownManagerToolStripMenuItem.Visible = True
        Else
            principal.DugunShutdownManagerToolStripMenuItem.Visible = False
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub
End Class