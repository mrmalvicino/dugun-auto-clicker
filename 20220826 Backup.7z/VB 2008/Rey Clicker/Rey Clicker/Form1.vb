﻿Public Class Form1
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vkey As Long) As Integer
    Declare Sub mouse_event Lib "user32" Alias "mouse_event" (ByVal dwFlags As Long, ByVal dx As Long, ByVal dy As Long, ByVal cButtons As Long, ByVal dwExtraInfo As Long)

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If RadioButton1.Checked = True Then
            CheckBox1.Text = "Activar CTRL"
            GroupBox1.Text = "Atajo del teclado"
            GroupBox2.Text = "Intervalo"
            GroupBox3.Text = "Lenguaje"
            Label3.Text = "Segundos"
        Else
            CheckBox1.Text = "Activate CTRL"
            GroupBox1.Text = "Hotkey"
            GroupBox2.Text = "Interval"
            GroupBox3.Text = "Language"
            Label3.Text = "Seconds"
        End If

        Dim q As Boolean
        Dim ctrl As Boolean
        q = GetAsyncKeyState(Keys.Q)
        ctrl = GetAsyncKeyState(Keys.ControlKey)

        If CheckBox1.Checked = False Then
            Label2.ForeColor = Color.Gray
            If q = True Then
                Timer1.Interval = TextBox1.Text * 1000
                mouse_event(&H2, 0, 0, 0, 1) 'el cursor se oprime (como un click)'
                mouse_event(&H4, 0, 0, 0, 1) 'el cursor se deja de oprimir'
            Else
                Timer1.Interval = 10
            End If
        Else
            Label2.ForeColor = Color.Black
            If ctrl And q = True Then
                Timer1.Interval = TextBox1.Text * 1000
                mouse_event(&H2, 0, 0, 0, 1) 'el cursor se oprime (como un click)'
                mouse_event(&H4, 0, 0, 0, 1) 'el cursor se deja de oprimir'
            Else
                Timer1.Interval = 10
            End If
        End If

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click
        If RadioButton1.Checked = True Then
            MsgBox("Dugun y todas las aplicaciones Dugun son desarrolladas por Maximiliano Malvicino, quien es el unico creador y programador de Dugun. Las aplicaciones Dugun se pueden descargar gratuitamente desde su sitio web oficial http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton2.Checked = True Then
            MsgBox("Dugun and all Dugun's applications are developed by Maximiliano Malvicino, who is the only programmer and creator of Dugun. Dugun's applications can be downloaded without paying from its official website http://www.dugun.webstarts.com", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        If RadioButton1.Checked = True Then
            MsgBox("RuneScape es una marca registrada de Jagex Ltd. Dugun y su creador no se relaciona de ninguna manera con RuneScape. El creador de Dugun no se hace responsable por cualquier ruptura de las reglas internas de RuneScape realizada por cualquier usuario de Dugun, ya que es responsabilidad del usuario.", MsgBoxStyle.Information, "Dugun")
        End If
        If RadioButton2.Checked = True Then
            MsgBox("RuneScape is a trademark of Jagex Ltd. Dugun and its creator is not related in any way with RuneScape. Dugun's creator is not responsible for any RuneScape rule breacking made by any Dugun user, as its the user's responsibility.", MsgBoxStyle.Information, "Dugun")
        End If
    End Sub
End Class
